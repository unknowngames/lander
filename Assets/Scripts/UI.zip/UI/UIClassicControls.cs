﻿using UnityEngine;
using System.Collections;

namespace Assets.Scripts.UI
{
    /// <summary>
    /// пользовательский интерфейс управления классического Lander
    /// </summary>
    public class UIClassicControls : MonoBehaviour
    {
        [SerializeField]
        public ISpaceshipMovable Spaceship;

        public void OnLeftTurnDown()
        {
            Debug.Log("Left turn down");
            if(Spaceship != null)
            {
                Spaceship.Turn(-1);
            }
        }

        public void OnLeftTurnUp()
        {
            Debug.Log("Left turn up");
            if (Spaceship != null)
            {
                Spaceship.Turn(0);
            }
        }

        public void OnRightTurnDown()
        {
            Debug.Log("Right turn down");
            if (Spaceship != null)
            {
                Spaceship.Turn(1);
            }
        }

        public void OnRightTurnUp()
        {
            Debug.Log("Right turn up");
            if (Spaceship != null)
            {
                Spaceship.Turn(0);
            }
        }

        public void OnThrottleSliderChanged(float throttle)
        {
            Debug.Log("Throttle: " + throttle);
            if (Spaceship != null)
            {
                Spaceship.Throttle(throttle);
            }
        }
    }

}
